var express = require('express');
var app = express();


var sql = require('mssql');
var db_server_ip = "127.0.0.1";
var config = {
    user:"sa",
    password:"wyh123",
    server:db_server_ip,
    database:'users'
};


var bodyParser = require('body-parser');
var urlencodedParser = bodyParser.urlencoded({ extended: false });

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(express.static(__dirname + '/public'));

app.get('/', function (req, res) {
    res.render('index.html');
});


app.post('/user_submit', urlencodedParser, function (req, res) {
    connection=sql.connect(config,function (err) {
        if (err) throw err;
        console.log("connected");
        var sql = "INSERT INTO users (UserName,FirstName,LastName,Email,Password,ResetCode,OrganisationID,Role) VALUES ('" + 
        req.body.User + "', '" + 
        req.body.FirstName + "', '" +
        req.body.LastName + "', '" +
        req.body.Email + "', '" +
        req.body.Password + "', '" +
        req.body.ResetCode + "', '" +
        req.body.OrganisationID  + "', '" +
        req.body.Role    
        + "')";
        connection.query(sql, function (err, result) {
            if (err) throw err;
            console.log("table created");
        });
    });
    res.sendFile('public/index.html', { root: __dirname });
});
app.get('/user_info', function(req, res, next) {
    connection=sql.connect(config,function (err) {
        if (err) throw err;
        console.log("connected");
        connection.query("SELECT * FROM users", function (err, result, fields) {
          if (err) throw err;
          console.log(result);
          res.send(result);
        });
      });
    });
app.listen(3000, function () {
   console.log('Listening on port 3000');
});