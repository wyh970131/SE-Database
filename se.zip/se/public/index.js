const person = document.getElementById('show');
show.addEventListener('click', async () => {
    event.preventDefault();
    console.log('123')
    const response = await fetch('/user_info');
    const body = await response.text();
    console.log(body)
    document.getElementById('play').innerHTML = body;

})